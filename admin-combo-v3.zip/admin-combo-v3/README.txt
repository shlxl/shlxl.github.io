Admin 合体版 v3
==================
把“文章管理（posts）”与“栏目管理（sections）”合并在一个补丁里：
- /api/list /api/new-local /api/promote /api/archive /api/republish /api/remove /api/update-meta /api/aliases
- /api/sections/*（list/create/toggle/rename/delete/trash/restore/nav-sync）
- /api/build /api/preview /api/deploy
- UI：/index.html（文章面板、带“栏目管理”按钮），/sections.html（栏目专页）

使用：
1) 解压覆盖到项目根（会写 blog-admin/）
2) node blog-admin/server.mjs
3) 打开 http://127.0.0.1:5174/ （或直接 /sections.html）

安全提示：
- “移入回收站”只移动栏目 index.md 到 docs/.trash/，不动子文章
- 改路径提供 dry-run 预演
- 导航同步支持写入 docs/.vitepress/sections.nav.json 或标记块内自动覆写
