#!/usr/bin/env node
import { createServer } from 'node:http';
import { parse as parseUrl } from 'node:url';
import path from 'node:path';
import fs from 'node:fs';
import { spawn } from 'node:child_process';

const __dirname = path.dirname(new URL(import.meta.url).pathname);
const PORT = Number(process.env.PORT || 5174);
const HOST = process.env.HOST || '127.0.0.1';
const PROJECT_ROOT = path.resolve(__dirname, '..');
const DOCS_DIR = path.join(PROJECT_ROOT, 'docs');
const BLOG_DIR = path.join(DOCS_DIR, 'blog');
const PUBLIC_DIR = path.join(__dirname, 'public');
const SCRIPTS_DIR = path.join(PROJECT_ROOT, 'scripts');

const JSON_HEADERS = {'Content-Type': 'application/json; charset=utf-8', 'Access-Control-Allow-Origin':'*'};

function send(res, code, data){
  res.writeHead(code, JSON_HEADERS);
  res.end(typeof data==='string'? data : JSON.stringify(data));
}
function notFound(res){ send(res, 404, {ok:false, error:'Not found'}) }
function readBody(req){ return new Promise((resolve,reject)=>{ let s=''; req.on('data',d=>s+=d); req.on('end',()=>{ try{ resolve(s?JSON.parse(s):{});}catch{reject(new Error('Invalid JSON'));} }); req.on('error',reject); }); }

function runNodeScript(rel, args=[]){
  return runCmd(process.execPath, [path.join(SCRIPTS_DIR, rel), ...args]);
}
function runCmd(cmd, args=[], opts={cwd: PROJECT_ROOT}){
  return new Promise((resolve,reject)=>{
    const p = spawn(cmd, args, { cwd: opts.cwd, shell: process.platform === 'win32', env: process.env });
    let out='', err='';
    p.stdout.on('data', d=> out+=String(d));
    p.stderr.on('data', d=> err+=String(d));
    p.on('close', c=> c===0 ? resolve({out,err}) : reject(Object.assign(new Error('fail'),{out,err,code:c})));
    p.on('error', reject);
  });
}

function parseFM(txt=''){
  const m = /^---\s*([\s\S]*?)\s*---/m.exec(txt);
  const fm = {title:'',date:'',publish:undefined,draft:undefined,tags:[],categories:[],cover:''};
  if(!m) return fm;
  const h = m[1];
  const get = k=>{ const re=new RegExp('^\\s*'+k+'\\s*:\\s*(.*)$','mi'); const mm=re.exec(h); return mm? mm[1].trim() : '' };
  const list = k=> get(k).replace(/^\[|\]$/g,'').split(',').map(s=>s.trim().replace(/^["']|["']$/g,'')).filter(Boolean);
  fm.title = get('title').replace(/^["']|["']$/g,'');
  fm.date = get('date').replace(/^["']|["']$/g,'');
  fm.cover = get('cover').replace(/^["']|["']$/g,'');
  fm.publish = (/^\s*publish\s*:\s*(true|false)/mi.exec(h)||[])[1];
  fm.draft = (/^\s*draft\s*:\s*(true|false)/mi.exec(h)||[])[1];
  try{ fm.tags = list('tags'); }catch{}
  try{ fm.categories = list('categories'); }catch{}
  return fm;
}
function walkMd(dir, out=[]){ if(!fs.existsSync(dir)) return out; for(const n of fs.readdirSync(dir)){ const p=path.join(dir,n); const s=fs.statSync(p); if(s.isDirectory()) walkMd(p,out); else if(/\.md$/i.test(n)) out.push(p); } return out; }
const slugOf = p=> path.basename(p).replace(/\.md$/i,'');

async function apiList(req,res){
  const files = walkMd(BLOG_DIR); const items=[];
  for(const f of files){
    const txt=fs.readFileSync(f,'utf8'); const fm=parseFM(txt);
    items.push({ slug: slugOf(f), path: path.relative(PROJECT_ROOT,f).replace(/\\/g,'/'),
      title: fm.title||slugOf(f), date: fm.date||'', publish: fm.publish==='true', draft: fm.draft==='true',
      tags: fm.tags||[], categories: fm.categories||[], cover: fm.cover||'',
      location: f.includes(`${path.sep}_local${path.sep}`)?'draft':'published'
    });
  }
  items.sort((a,b)=> String(b.date).localeCompare(String(a.date)));
  send(res, 200, {ok:true, items});
}

async function apiNewLocal(req,res){
  const b = await readBody(req);
  const args=[];
  if(b.title) args.push('--title', String(b.title));
  if(b.desc) args.push('--desc', String(b.desc));
  if(b.tags) args.push('--tags', Array.isArray(b.tags)? b.tags.join(',') : String(b.tags));
  if(b.cat) args.push('--cat', String(b.cat));
  if(b.slug) args.push('--slug', String(b.slug));
  if(b.cover) args.push('--cover', String(b.cover));
  try{ const r=await runNodeScript('new-post-local.mjs', args); send(res,200,{ok:true,out:r.out.trim()}); }
  catch(e){ send(res,500,{ok:false,error:e.message,out:e.out,err:e.err}); }
}
async function apiPromote(req,res){
  const b=await readBody(req); if(!b.slug) return send(res,400,{ok:false,error:'missing slug'});
  const args=[ String(b.slug) ]; if(b.setDate) args.push('--set-date');
  try{ const r=await runNodeScript('post-promote.mjs', args); send(res,200,{ok:true,out:r.out.trim()}); }
  catch(e){ send(res,500,{ok:false,error:e.message,out:e.out,err:e.err}); }
}
async function apiArchive(req,res){
  const b=await readBody(req); if(!b.slug) return send(res,400,{ok:false,error:'missing slug'});
  try{ const r=await runNodeScript('post-archive.mjs', [ String(b.slug) ]); send(res,200,{ok:true,out:r.out.trim()}); }
  catch(e){ send(res,500,{ok:false,error:e.message,out:e.out,err:e.err}); }
}
async function apiRemove(req,res){
  const b=await readBody(req); if(!b.slug) return send(res,400,{ok:false,error:'missing slug'});
  const args=[ String(b.slug) ]; if(b.hard) args.push('--hard');
  try{ const r=await runNodeScript('post-remove.mjs', args); send(res,200,{ok:true,out:r.out.trim()}); }
  catch(e){ send(res,500,{ok:false,error:e.message,out:e.out,err:e.err}); }
}
async function apiAliases(req,res){
  try{ const r=await runNodeScript('gen-alias-redirects.mjs', []); send(res,200,{ok:true,out:r.out.trim()}); }
  catch(e){ send(res,500,{ok:false,error:e.message,out:e.out,err:e.err}); }
}
async function apiBuild(req,res){
  try{ const npx = process.platform==='win32' ? 'npx.cmd' : 'npx'; const r=await runCmd(npx, ['vitepress','build','docs']); send(res,200,{ok:true,out:r.out.trim()}); }
  catch(e){ send(res,500,{ok:false,error:e.message,out:e.out,err:e.err}); }
}
async function apiPreview(req,res){
  try{ const npx = process.platform==='win32' ? 'npx.cmd' : 'npx'; const r=await runCmd(npx, ['vitepress','preview','docs']); send(res,200,{ok:true,out:r.out.trim()}); }
  catch(e){ send(res,500,{ok:false,error:e.message,out:e.out,err:e.err}); }
}
async function apiDeploy(req,res){
  try{ const r=await runNodeScript('deploy-local.mjs', []); send(res,200,{ok:true,out:r.out.trim()}); }
  catch(e){ send(res,500,{ok:false,error:e.message,out:e.out,err:e.err}); }
}

function serveStatic(req,res){
  const { pathname } = parseUrl(req.url);
  let p = pathname || '/';
  if(p==='/') p='/index.html';
  const file = path.join(PUBLIC_DIR, p);
  if(!file.startsWith(PUBLIC_DIR)) return notFound(res);
  if(fs.existsSync(file) && fs.statSync(file).isFile()){
    const ext = path.extname(file).toLowerCase();
    const map = {'.html':'text/html; charset=utf-8','.js':'application/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml'};
    res.writeHead(200, {'Content-Type': map[ext] || 'application/octet-stream'});
    fs.createReadStream(file).pipe(res);
  }else{ notFound(res); }
}

const server = createServer(async (req,res)=>{
  const { pathname } = parseUrl(req.url);
  if(req.method==='OPTIONS'){
    res.writeHead(204, {'Access-Control-Allow-Origin':'*','Access-Control-Allow-Methods':'GET,POST,OPTIONS','Access-Control-Allow-Headers':'content-type'});
    return res.end();
  }
  try{
    if(req.method==='GET' && pathname==='/api/list') return apiList(req,res);
    if(req.method==='POST' && pathname==='/api/new-local') return apiNewLocal(req,res);
    if(req.method==='POST' && pathname==='/api/promote') return apiPromote(req,res);
    if(req.method==='POST' && pathname==='/api/archive') return apiArchive(req,res);
    if(req.method==='POST' && pathname==='/api/remove') return apiRemove(req,res);
    if(req.method==='POST' && pathname==='/api/aliases') return apiAliases(req,res);
    if(req.method==='POST' && pathname==='/api/build') return apiBuild(req,res);
    if(req.method==='POST' && pathname==='/api/preview') return apiPreview(req,res);
    if(req.method==='POST' && pathname==='/api/deploy') return apiDeploy(req,res);
    return serveStatic(req,res);
  }catch(e){ send(res,500,{ok:false,error:e.message}); }
});

server.listen(PORT, HOST, ()=>{
  console.log(`[admin] running at http://${HOST}:${PORT}`);
  console.log(`[admin] root: ${PROJECT_ROOT}`);
});
