Sections Manager v2（带导航同步 & 回收站恢复）
=================================================
包含：
- 专用面板 /sections.html
- API：/api/sections（list/create/toggle/rename/delete）、/api/sections/trash、/api/sections/restore
- 导航同步：/api/sections/nav-sync（生成 docs/.vitepress/sections.nav.json，并可写入 config.* 标记块）
- 兼容旧接口：/api/list、/api/update-meta
- 主面板 /index.html 已内置「栏目管理」按钮

使用：
1) 解压到项目根（覆盖 blog-admin/ 目录）
2) 启动：node blog-admin/server.mjs
3) 打开：http://127.0.0.1:5174/sections.html（或根面板点击“栏目管理”）

提示：
- 删除栏目默认=仅下架（publish:false）；硬删除=把 index.md 挪到 docs/.trash/，不动子文章。
- 导航自动写入：在 docs/.vitepress/config.* 的 nav 里加入：
   /* ADMIN NAV START */
     // admin will inject here
   /* ADMIN NAV END */
  然后调用 /api/sections/nav-sync 或在页面点“同步导航”。
