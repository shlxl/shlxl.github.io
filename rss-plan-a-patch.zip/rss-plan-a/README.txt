方案A：给 docs/rss.md 添加 frontmatter（不搬文件）
================================================
作用：把 `docs/rss.md` 标记为“页面”，防止被博客列表/聚合收录。

写入的前置属性（默认）：
  type: page
  list: false
  hidden: true
  publish: false   # 可用 --keep-publish 跳过

使用：
1) 解压到仓库根目录（会写 scripts/）
2) 运行：
   node scripts/rss-mark-page.mjs            # 默认尝试 docs/rss.md，找不到再尝试 docs/blog/rss.md
   # 或指定路径：
   node scripts/rss-mark-page.mjs --path docs/rss.md
   # 只预览变更：
   node scripts/rss-mark-page.mjs --dry-run
   # 不修改 publish：
   node scripts/rss-mark-page.mjs --keep-publish

完成后，`docs/rss.md` 顶部会有：
---
type: page
list: false
hidden: true
publish: false
---
然后你的前台聚合脚本（如果尊重这些字段）就不会把它当作文章展示。
