RSS栏修复补丁（适配 Admin Combo v3）
-------------------------------------
- 支持 frontmatter: `list: false` 或 `hidden: true`，使页面不进入文章列表；
- 支持 `docs/blog/.adminignore`（默认包含 rss.md、blog.md）；
- `/api/list` 返回项新增 `hidden` 字段；
- admin.js 在渲染三个文章列表时自动过滤 `hidden`。

应用：
1) 将 `blog-admin/server.mjs` 与 `blog-admin/public/admin.js` 中对应片段合并或替换；
2) 在 `docs/blog/` 新建 `.adminignore`（可参考 `.adminignore.sample`），写入要隐藏的文件名或通配；
3) 或在要隐藏的页面 frontmatter 写入 `list: false`。

示例 frontmatter：
---
title: RSS 订阅
list: false
---
