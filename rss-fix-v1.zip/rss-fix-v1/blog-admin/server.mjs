#!/usr/bin/env node
import { createServer } from 'node:http';
import { parse as parseUrl } from 'node:url';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import fs from 'node:fs';
import { spawn } from 'node:child_process';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 5174);
const HOST = process.env.HOST || '127.0.0.1';

const PROJECT_ROOT = path.resolve(__dirname, '..');
const DOCS_DIR = path.join(PROJECT_ROOT, 'docs');
const BLOG_DIR = path.join(DOCS_DIR, 'blog');
const PUBLIC_DIR = path.join(__dirname, 'public');
const SCRIPTS_DIR = path.join(PROJECT_ROOT, 'scripts');

const PREVIEW_PORT = Number(process.env.PREVIEW_PORT || 4173);
const DIST_DIR = path.join(DOCS_DIR, '.vitepress', 'dist');
const TRASH_DIR = path.join(DOCS_DIR, '.trash');
const LOCAL_DIR = path.join(BLOG_DIR, '_local');

const JSON_HEADERS = { 'Content-Type':'application/json; charset=utf-8', 'Access-Control-Allow-Origin':'*' };

function send(res, code, data){ res.writeHead(code, JSON_HEADERS); res.end(typeof data==='string'?data:JSON.stringify(data)); }
function notFound(res){ send(res,404,{ok:false,error:'Not found'}); }
function readBody(req){ return new Promise((resolve,reject)=>{ let s=''; req.on('data',d=>s+=d); req.on('end',()=>{ try{ resolve(s?JSON.parse(s):{});}catch{reject(new Error('Invalid JSON'));} }); req.on('error',reject); }); }
function runCmd(cmd, args=[], opts={cwd: PROJECT_ROOT}){
  return new Promise((resolve,reject)=>{
    const p = spawn(cmd, args, { cwd: opts.cwd, shell: process.platform==='win32', env: process.env });
    let out='', err=''; p.stdout.on('data', d=> out+=String(d)); p.stderr.on('data', d=> err+=String(d));
    p.on('close', c=> c===0 ? resolve({out,err}) : reject(Object.assign(new Error('fail'),{out,err,code:c})));
    p.on('error', reject);
  });
}
const runNodeScript = (rel, args=[]) => runCmd(process.execPath, [path.join(SCRIPTS_DIR, rel), ...args]);

const relOf  = p=> path.relative(BLOG_DIR, p).replace(/\\/g,'/');
const isSection = p => path.basename(p).toLowerCase()==='index.md';
const slugOf = p=> path.basename(p).replace(/\.md$/i,'');

function parseFM(txt=''){
  const m = /^---\s*([\s\S]*?)\s*---/m.exec(txt);
  const fm = {title:'',date:'',publish:undefined,draft:undefined,tags:[],categories:[],cover:'',list:undefined,hidden:undefined};
  if(!m) return fm;
  const h = m[1];
  const get = k=>{ const re=new RegExp('^\\s*'+k+'\\s*:\\s*(.*)$','mi'); const mm=re.exec(h); return mm? mm[1].trim() : '' };
  const list = k=> get(k).replace(/^\[|\]$/g,'').split(',').map(s=>s.trim().replace(/^["']|["']$/g,'')).filter(Boolean);
  fm.title = get('title').replace(/^["']|["']$/g,'');
  fm.date = get('date').replace(/^["']|["']$/g,'');
  fm.cover = get('cover').replace(/^["']|["']$/g,'');
  fm.publish = (/^\s*publish\s*:\s*(true|false)/mi.exec(h)||[])[1];
  fm.draft = (/^\s*draft\s*:\s*(true|false)/mi.exec(h)||[])[1];
  fm.list = (/^\s*list\s*:\s*(true|false|0|1)/mi.exec(h)||[])[1];
  fm.hidden = (/^\s*hidden\s*:\s*(true|false)/mi.exec(h)||[])[1];
  try{ fm.tags = list('tags'); }catch{}; try{ fm.categories = list('categories'); }catch{};
  return fm;
}
function walkMd(dir, out=[]){
  if(!fs.existsSync(dir)) return out;
  for(const n of fs.readdirSync(dir)){
    const p=path.join(dir,n);
    const s=fs.statSync(p);
    if(s.isDirectory()) walkMd(p,out);
    else if(/\.md$/i.test(n)) out.push(p);
  }
  return out;
}

// --- ignore list (.adminignore) + hidden logic ---
function loadIgnores(){
  const file = path.join(BLOG_DIR, '.adminignore');
  let lines = [];
  if (fs.existsSync(file)) {
    lines = fs.readFileSync(file,'utf8').split(/\r?\n/).map(s=>s.trim()).filter(s=>s && !s.startsWith('#'));
  }
  lines.push('rss.md', 'blog.md'); // 默认忽略：根层的 rss.md / blog.md
  return Array.from(new Set(lines));
}
function toRegex(glob){
  const esc = s=> s.replace(/[.+^${}()|[\]\\]/g,'\\$&');
  let re = '^' + glob.split('*').map(esc).join('.*') + '$';
  re = re.replace(/\?/g,'.');
  return new RegExp(re, 'i');
}
const IGNORE_PATTERNS = loadIgnores().map(g=>({ glob:g, re:toRegex(g) }));
function shouldIgnore(rel, abs, fm){
  if (String(fm.list).toLowerCase()==='false' || String(fm.list)==='0') return true;
  if (String(fm.hidden).toLowerCase()==='true') return true;
  if (IGNORE_PATTERNS.some(p=> p.re.test(rel))) return true;
  const base = path.basename(abs).toLowerCase();
  if (path.dirname(abs)===BLOG_DIR && (base==='rss.md' || base==='blog.md')) return true;
  return false;
}

function setPublishFlag(file, publish){
  const fm = /^---\s*([\s\S]*?)\s*---/m;
  let txt = fs.readFileSync(file,'utf8');
  const m = fm.exec(txt); if(!m) throw new Error('frontmatter missing: '+file);
  let head = m[1];
  const put=(k,v)=>{ const re=new RegExp(`^\\s*${k}\\s*:\\s*.*$`,'mi'); head = re.test(head) ? head.replace(re, `${k}: ${v}`) : (head+`\\n${k}: ${v}`); };
  put('publish', publish ? 'true' : 'false');
  if(publish) put('draft','false');
  txt = txt.replace(fm, `---\\n${head.trim()}\\n---`);
  fs.writeFileSync(file, txt, 'utf8');
}
function updateFrontmatter(file, patch={}){
  const FM = /^---\\s*([\\s\\S]*?)\\s*---/m;
  const read = fs.readFileSync(file,'utf8');
  const m = FM.exec(read);
  if(!m) throw new Error('frontmatter missing: '+file);
  let head = m[1];
  const put = (k, v) => {
    if (v === undefined || v === null) return;
    const re = new RegExp(`^\\s*${k}\\s*:\\s*.*$`,'mi');
    const val = Array.isArray(v) ? `[${v.map(x=>String(x)).join(', ')}]` : String(v);
    head = re.test(head) ? head.replace(re, `${k}: ${val}`) : (head + `\\n${k}: ${val}`);
  };
  for (const [k,v] of Object.entries(patch||{})) put(k, v);
  const out = read.replace(FM, `---\\n${head.trim()}\\n---`); fs.writeFileSync(file, out, 'utf8');
}

// ---------- API: list（含 hidden 字段） ----------
async function apiList(req,res){
  const files = walkMd(BLOG_DIR);
  const items = files.map(f=>{
    const txt = fs.readFileSync(f,'utf8'); const fm = parseFM(txt);
    const rel = relOf(f);
    const hidden = shouldIgnore(rel, f, fm);
    return {
      slug: path.basename(f).replace(/\\.md$/i,''),
      path: path.relative(PROJECT_ROOT,f).replace(/\\\\/g,'/'),
      rel,
      abs:  f,
      title: fm.title || path.basename(f).replace(/\\.md$/i,''),
      date: fm.date || '',
      publish: fm.publish === 'true',
      draft: fm.draft === 'true',
      tags: fm.tags || [],
      categories: fm.categories || [],
      cover: fm.cover || '',
      kind: isSection(f) ? 'section' : 'post',
      hidden
    };
  });
  items.sort((a,b)=> String(b.date).localeCompare(String(a.date)));
  send(res, 200, { ok:true, items });
}
export { apiList, updateFrontmatter };
