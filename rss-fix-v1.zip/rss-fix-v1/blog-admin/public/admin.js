// 只展示 !hidden 的文章项
const $=(s,r=document)=>r.querySelector(s);const $$=(s,r=document)=>Array.from(r.querySelectorAll(s));
const toast=(m,ok=true)=>{const t=$('#toast');t.textContent=m;t.style.borderColor=ok?'#2b376c':'#804040';t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2600);};
let ALL_ITEMS=[], QUERY='';

async function api(path, method='GET', data){
  const opt = { method, headers:{ 'Content-Type':'application/json' } };
  if(data) opt.body = JSON.stringify(data);
  const res = await fetch(path, opt);
  const json = await res.json().catch(()=>({ok:false, error:'Bad JSON'}));
  if(!json.ok){
    const err = new Error(json.error || '操作失败');
    err.detail = { out: json.out, err: json.err };
    throw err;
  }
  return json;
}
function matches(item, q){
  if(!q) return true;
  const s = q.toLowerCase();
  return [
    item.title, item.slug, item.date, item.rel,
    (item.tags||[]).join(' '),
    (item.categories||[]).join(' ')
  ].join(' ').toLowerCase().includes(s);
}
function render(items){
  const data = items.filter(x=>matches(x, QUERY));
  const isDraft   = x=> x.abs.includes('/_local/');
  const D = data.filter(x=>x.kind==='post' && isDraft(x) && !x.hidden);
  const P = data.filter(x=>x.kind==='post' && !isDraft(x) &&  x.publish && !x.hidden);
  const A = data.filter(x=>x.kind==='post' && !isDraft(x) && !x.publish && !x.hidden);

  const tag=arr=>arr.map(t=>`<span class="badge">${t}</span>`).join('');
  const rowPost = (x, extraBtns='')=>`<tr>
    <td>${x.title}</td><td>${x.slug}</td><td>${x.date||''}</td>${x.publish!==undefined?`<td>${x.publish?'✅':'❌'}</td>`:''}
    <td>${tag(x.tags||[])}</td><td>${(x.categories||[]).join(', ')}</td>
    <td class="row-actions">
      ${extraBtns}
      <button data-act="open"  data-rel="${x.rel}">VS Code</button>
      <button data-act="edit"  data-rel="${x.rel}">编辑</button>
      <button data-act="remove" data-rel="${x.rel}">回收站</button>
      <button data-act="remove-hard" data-rel="${x.rel}">永久删</button>
    </td>
  </tr>`;

  const fill=(sel, list)=>{ const el=document.querySelector(sel+' tbody'); if(el) el.innerHTML=list.map(x=>rowPost(x, sel.includes('draft')?`<button data-act="promote" data-rel="${x.rel}">发布</button>`: sel.includes('pubs')?`<button data-act="archive" data-rel="${x.rel}">下架</button>`:`<button data-act="archive" data-rel="${x.rel}">下架</button><button data-act="republish" data-rel="${x.rel}">重新上架</button>`)).join(''); };
  fill('#tbl-drafts', D); fill('#tbl-pubs', P); fill('#tbl-archived', A);
}
async function refresh(){ const r = await api('/api/list'); ALL_ITEMS = r.items || []; render(ALL_ITEMS); }
export { refresh };
