Admin 合体版 v4（整合补丁）
==============================
在 v3 基础上整合：
- RSS/page 过滤与显式“页面”分栏：支持 frontmatter `list:false`/`hidden:true`/`type: page`；支持 `docs/blog/.adminignore`；
- /api/list 返回 `type` 与 `hidden` 字段；
- 主面板新增“页面 / 特殊页”卡片，可一键：隐藏、显示、标记为 page；
- 继续保留：文章管理（草稿/发布/下架/回收站）、栏目管理（index.md 识别、新建、上下架、改路径、栏目回收站/恢复）、导航同步、构建/预览/部署。

使用：
1) 解压覆盖到仓库根（会写 blog-admin/）
2) node blog-admin/server.mjs
3) 打开 http://127.0.0.1:5174/

可选：在 docs/blog/.adminignore 写入想排除的文件或通配；默认已包含 rss.md、blog.md。
示例 frontmatter：
---
title: RSS
type: page
list: false
---
