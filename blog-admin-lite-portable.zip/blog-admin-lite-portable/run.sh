#!/usr/bin/env bash
# 用法： ./run.sh -r /path/to/project [-p 5174] [-s /path/to/scripts]
set -e
PORT=5174
ROOT=""
SCRIPTS=""
while getopts "r:p:s:" opt; do
  case $opt in
    r) ROOT="$OPTARG";;
    p) PORT="$OPTARG";;
    s) SCRIPTS="$OPTARG";;
  esac
done
if [ -z "$ROOT" ]; then echo "需要 -r 指向你的项目根目录（含 docs/ 与 scripts/）"; exit 1; fi
export PROJECT_ROOT="$ROOT"
[ -n "$SCRIPTS" ] && export SCRIPTS_DIR="$SCRIPTS"
export PORT="$PORT"
node server.mjs
