
# 用法：.\run.ps1 -Root "D:\homepage" [-Port 5175] [-Scripts "D:\homepage\scripts"]
param(
  [string]$Root,
  [int]$Port = 5174,
  [string]$Scripts = ""
)
if (-not $Root) { Write-Error "需要 -Root 指向你的项目根目录（含 docs/ 与 scripts/）"; exit 1 }
$env:PROJECT_ROOT = $Root
if ($Scripts -ne "") { $env:SCRIPTS_DIR = $Scripts }
$env:PORT = $Port
node server.mjs
